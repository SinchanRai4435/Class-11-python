import pygame 

import math
pygame.init()
pygame.font.init()
pygame.mixer.init(48000, -16, 1, 1024)



height = 800
width = 600
screen = pygame.display.set_mode((height, width))
clock = pygame.time.Clock()
score = 1
font = pygame.font.Font('freesansbold.ttf', 32)
new_font = pygame.font.Font('freesansbold.ttf', 64)
time_font = pygame.font.Font('freesansbold.ttf', 32)
time_font1 = pygame.font.Font('freesansbold.ttf', 32)
time_font2 = pygame.font.Font('freesansbold.ttf', 32)
new_font2 = pygame.font.Font('freesansbold.ttf', 32)
new_font3 = pygame.font.Font('freesansbold.ttf', 32)

 
a = 0
b = 0
c = 0
chk = 0
background = pygame.transform.scale(
    pygame.image.load('ground.jpg'), (height, width))
playerImg = (pygame.image.load('shooting.png'))
playerX = 100
playerY = 300
enemyImg = pygame.image.load ('dartboard.png')
enemyX = 700
enemyY = 100
enemyY_change = 1+score
bulletImg = pygame.image.load('bullet.png')
bulletX = 100
bulletY = 300
bullet_state = 0
bulletX_change = 15
# player


def player(x, y):
    screen.blit(playerImg, (x, y))


# enemy
def enemy(x, y):
    screen.blit(enemyImg, (x, y))

# bullet


def bullet(x, y):
    screen.blit(bulletImg, (x, y))


def fire_bullet(x, y):
    
    bullet_state = 1
    screen.blit(bulletImg, (x+16, y+10))


def isCOLLISION(enemyX, enemyY, bulletX, bulletY):
    distance = math.sqrt((math.pow(enemyX - bulletX, 2)) +
                         (math.pow(enemyY - bulletY, 2)))
    if distance <= 27:
        return True
    else:
        return False


def show_score(x, y):
    score_val = font.render('Score:' + str(score), True, (255, 255, 255))
    screen.blit(score_val, (x, y))


run = True


while run:

    
    
    clock.tick(60)
    screen.blit(background, (0, 0))
    c = c + 1
    a = c//60
    d = score*3 - a 
    if d <= 3:
        time = time_font1.render('time:'+str(d) + 's', True, (255, 0, 0))
        screen.blit(time, (660, 10))
    elif d > 3 and d <= 8:
        time = time_font2.render('time:'+str(d) + 's', True, (255, 102, 0))
        screen.blit(time, (660, 10))
    elif d>=9:
        time = time_font.render('time:'+str(d) + 's', True, (0, 255, 0))
        screen.blit(time, (660, 10))

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP:
                playerY -= 20
            if event.key == pygame.K_DOWN:
                playerY += 20
            if event.key == pygame.K_SPACE:
    

                if bullet_state == 0:
                    bulletX = playerX
                    bulletY = playerY
                    bullet_state = 1
                fire_bullet(bulletX,  playerY)

    enemyY += enemyY_change
    if enemyY <= 0:
        enemyY_change = 1 + score
        enemyY += enemyY_change
    elif enemyY >= 570:
        enemyY_change = -1 - score
        enemyY += enemyY_change

    if bulletX >= 700:
        bulletX = 480
        bullet_state = 0

    if bullet_state == 1:
        fire_bullet(bulletX, bulletY)
        bulletX += bulletX_change

    collision = isCOLLISION(enemyX, enemyY, bulletX, bulletY)
    if collision:

    
        
        bullet_state = 1
        score += 1
        chk = 1
        pygame.display.update()
        enemyX = 700
    player(playerX, playerY)

    enemy(enemyX, enemyY)
    show_score(10, 10)
    pygame.display.flip()

    if chk == 1:
        chk = 0
        a = 0
        c = 0
        a = a+1
        print(3*score)
        print(a)
    elif a == 3*score:
        print('hello')
        while b < 180:
            b = b+1
            for event in pygame.event.get():
                if event.key == pygame.QUIT:
                    run = False
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        b=179
                    else:
                        pass
            screen.blit(background, (0, 0))
            game_over = new_font.render("TIME'S UP!", True, (255, 255, 255))
            screen.blit(game_over, (250, 250))
            fin_score = font.render('Score:'+str(score), True, (255, 255, 255))
            screen.blit(fin_score, (340, 310))
            new_game = new_font2.render('new game in :'+ str(3-(b//60)),True, (255,255,255))
            screen.blit(new_game, (290, 350))
            credit = new_font3.render('made by sinchan' , True, (255,255,255)) 
            screen.blit(credit,(10,560))
            pygame.display.flip()
            clock.tick(60)
            run = True
        score = 1
        d=0
        a=0
        b=0
        c=0
        bulletX = 100
        bulletY = 300
        bullet_state = 0
        enemyX = 700
        enemyY = 100
        playerX = 100
        playerY = 300
        chk = 1
        enemyY_change = 1 + score
        enemyY += enemyY_change